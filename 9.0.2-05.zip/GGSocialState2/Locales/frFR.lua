local L = LibStub("AceLocale-3.0"):NewLocale("GGSocialState", "frFR", false)

if not L then return end


