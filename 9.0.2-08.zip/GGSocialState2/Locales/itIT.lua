local L = LibStub("AceLocale-3.0"):NewLocale("GGSocialState", "itIT", false)

if not L then return end


