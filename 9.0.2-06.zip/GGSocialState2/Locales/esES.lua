local L = LibStub("AceLocale-3.0"):NewLocale("GGSocialState", "esES", false)

if not L then return end


